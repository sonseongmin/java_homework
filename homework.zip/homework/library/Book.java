package library;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private int publishYear;
    private boolean isAvailable;

    public Book() {
        this.isAvailable = true;
    }

    public Book(String title, String author, String isbn, int publishYear) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.publishYear = publishYear;
        this.isAvailable = true;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public int getPublishYear() { return publishYear; }
    public void setPublishYear(int publishYear) { this.publishYear = publishYear; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }

    public boolean checkOut() {
        if (isAvailable) {
            isAvailable = false;
            return true;
        }
        return false;
    }

    public void returnBook() {
        isAvailable = true;
    }

    @Override
    public String toString() {
        return String.format("å ����: %s\t����: %s\tISBN: %s\t���ǳ⵵: %d\t���� ���� ����: %s",
                title, author, isbn, publishYear, isAvailable ? "����" : "���� ��");
    }
}

// Library.java
package workshop.library.entity;

import java.util.*;

public class Library {
    private String name;
    private List<Book> books;

    public Library(String name) {
        this.name = name;
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("������ �߰��Ǿ����ϴ�: " + book.getTitle());
    }

    public List<Book> findBookByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                result.add(book);
            }
        }
        return result;
    }

    public List<Book> findBooksByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                result.add(book);
            }
        }
        return result;
    }

    public Book findBookByISBN(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    public boolean checkOutBook(String isbn) {
        Book book = findBookByISBN(isbn);
        return book != null && book.checkOut();
    }

    public boolean returnBook(String isbn) {
        Book book = findBookByISBN(isbn);
        if (book != null) {
            book.returnBook();
            return true;
        }
        return false;
    }

    public List<Book> getAvailableBooks() {
        List<Book> available = new ArrayList<>();
        for (Book book : books) {
            if (book.isAvailable()) {
                available.add(book);
            }
        }
        return available;
    }

    public List<Book> getAllBooks() {
        return books;
    }

    public int getTotalBooks() {
        return books.size();
    }

    public int getAvailableBooksCount() {
        return (int) books.stream().filter(Book::isAvailable).count();
    }

    public int getBorrowedBooksCount() {
        return getTotalBooks() - getAvailableBooksCount();
    }

    public void printLibraryStatus() {
        System.out.println("===== " + name + " =====");
        System.out.println("��ü ���� ��: " + getTotalBooks());
        System.out.println("���� ���� ���� ��: " + getAvailableBooksCount());
        System.out.println("���� ���� ���� ��: " + getBorrowedBooksCount());
    }
}

// LibraryManagementSystem.java
package workshop.library.control;

import workshop.library.entity.*;
import java.util.List;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library("�߾� ������");

        addSampleBooks(library);
        library.printLibraryStatus();

        System.out.println("\n===== ���� �˻� �׽�Ʈ =====");
        testFindBook(library);

        System.out.println("\n===== ���� ���� �׽�Ʈ =====");
        testCheckOut(library);
        library.printLibraryStatus();

        System.out.println("\n===== ���� �ݳ� �׽�Ʈ =====");
        testReturn(library);
        library.printLibraryStatus();

        System.out.println("===== ���� ������ ���� ��� =====");
        displayAvailableBooks(library);
    }

    private static void addSampleBooks(Library library) {
        library.addBook(new Book("�ڹ� ���α׷���", "���ڹ�", "978-89-01-12345-6", 2022));
        library.addBook(new Book("��ü������ ��ǰ� ����", "����ȣ", "978-89-01-67890-1", 2015));
        library.addBook(new Book("Clean Code", "Robert C. Martin", "978-0-13-235088-4", 2008));
        library.addBook(new Book("Effective Java", "Joshua Bloch", "978-0-13-468599-1", 2018));
        library.addBook(new Book("Head First Java", "Kathy Sierra", "978-0-596-00920-5", 2005));
        library.addBook(new Book("�ڹ��� ����", "���ü�", "978-89-01-14077-4", 2019));
    }

    private static void testFindBook(Library library) {
        List<Book> byTitle = library.findBookByTitle("�ڹ��� ����");
        System.out.println("�������� �˻� ���:");
        byTitle.forEach(System.out::println);

        List<Book> byAuthor = library.findBooksByAuthor("Robert C. Martin");
        System.out.println("\n���ڷ� �˻� ���:");
        byAuthor.forEach(System.out::println);
    }

    private static void testCheckOut(Library library) {
        if (library.checkOutBook("978-89-01-14077-4")) {
            System.out.println("���� ���� ����!");
            System.out.println("����� ���� ����:");
            System.out.println(library.findBookByISBN("978-89-01-14077-4"));
        } else {
            System.out.println("���� ���� ����!");
        }
    }

    private static void testReturn(Library library) {
        if (library.returnBook("978-89-01-14077-4")) {
            System.out.println("���� �ݳ� ����!");
            System.out.println("�ݳ��� ���� ����:");
            System.out.println(library.findBookByISBN("978-89-01-14077-4"));
        } else {
            System.out.println("���� �ݳ� ����!");
        }
    }

    private static void displayAvailableBooks(Library library) {
        library.getAvailableBooks().forEach(book -> {
            System.out.println(book);
            System.out.println("------------------------");
        });
    }
}

