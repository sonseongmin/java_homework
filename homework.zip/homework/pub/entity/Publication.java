// Publication.java
package pub.entity;

import java.time.LocalDate;

public abstract class Publication {
    private String title;
    private LocalDate publishDate;
    private int page;
    private int price;

    public Publication() {}

    public Publication(String title, LocalDate publishDate, int page, int price) {
        this.title = title;
        this.publishDate = publishDate;
        this.page = page;
        this.price = price;
    }

    public String getTitle() { return title; }
    public LocalDate getPublishDate() { return publishDate; }
    public int getPage() { return page; }
    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }

    @Override
    public String toString() {
        return title;
    }
}

// Novel.java
package workshop.book.entity;

public class Novel extends Publication {
    private String author;
    private String genre;

    public Novel(String title, String author, String genre, int page, int price, java.time.LocalDate publishDate) {
        super(title, publishDate, page, price);
        this.author = author;
        this.genre = genre;
    }

    @Override
    public String toString() {
        return String.format("%s [�Ҽ�] ����:%s, �帣:%s, %d��, %d��, ������:%s",
                getTitle(), author, genre, getPage(), getPrice(), getPublishDate());
    }
}

// Magazine.java
package workshop.book.entity;

public class Magazine extends Publication {
    private String publishPeriod;

    public Magazine(String title, String publishPeriod, int page, int price, java.time.LocalDate publishDate) {
        super(title, publishDate, page, price);
        this.publishPeriod = publishPeriod;
    }

    @Override
    public String toString() {
        return String.format("%s [����] �����ֱ�:%s, %d��, %d��, ������:%s",
                getTitle(), publishPeriod, getPage(), getPrice(), getPublishDate());
    }
}

// ReferenceBook.java
package workshop.book.entity;

public class ReferenceBook extends Publication {
    private String field;

    public ReferenceBook(String title, String field, int page, int price, java.time.LocalDate publishDate) {
        super(title, publishDate, page, price);
        this.field = field;
    }

    @Override
    public String toString() {
        return String.format("%s [������] �о�:%s, %d��, %d��, ������:%s",
                getTitle(), field, getPage(), getPrice(), getPublishDate());
    }
}

// Cart.java
package workshop.book.control;

import workshop.book.entity.*;
import java.util.*;

public class Cart {
    private List<Publication> items = new ArrayList<>();

    public void add(Publication p) {
        items.add(p);
    }

    public void remove(Publication p) {
        items.remove(p);
    }

    public List<Publication> getItems() {
        return items;
    }

    public void clear() {
        items.clear();
    }
}

// BookShop.java
package workshop.book.control;

import workshop.book.entity.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class BookShop {
    public static void main(String[] args) {
        List<Publication> publications = List.of(
                new Magazine("����ũ�μ���Ʈ", "�ſ�", 328, 9900, LocalDate.of(2007, 10, 1)),
                new Magazine("�濵����ǻ��", "�ſ�", 316, 9000, LocalDate.of(2007, 10, 3)),
                new Novel("���߿�", "����������������", "����Ҽ�", 396, 9800, LocalDate.of(2007, 7, 1)),
                new Novel("���ѻ꼺", "����", "���ϼҼ�", 383, 11000, LocalDate.of(2007, 4, 14)),
                new ReferenceBook("�ǿ��������α׷���", "����Ʈ�������", 496, 25000, LocalDate.of(2007, 1, 14)),
                new Novel("�ҳ��̿´�", "�Ѱ�", "�����Ҽ�", 216, 15000, LocalDate.of(2014, 5, 1)),
                new Novel("�ۺ������ʴ´�", "�Ѱ�", "�����Ҽ�", 332, 15120, LocalDate.of(2021, 9, 9))
        );

        System.out.println("==== ���� ���� ��� ====");
        int index = 1;
        for (Publication p : publications) {
            System.out.println(index++ + ". " + p);
        }

        System.out.println("\n==== ���� ���� ====");
        Publication book = publications.stream()
                .filter(p -> p.getTitle().equals("�ۺ������ʴ´�"))
                .findFirst().orElse(null);
        if (book != null) {
            int before = book.getPrice();
            int newPrice = (int)(before * 0.8);
            book.setPrice(newPrice);
            System.out.printf("%s ���� �� ����: %d��\n", book.getTitle(), before);
            System.out.printf("%s ���� �� ����: %d��\n", book.getTitle(), newPrice);
            System.out.printf("����: %d��\n", before - newPrice);
        }

        System.out.println("\n===== ���ǹ� ��� �м� =====");
        Map<String, List<Publication>> typeGroups = publications.stream()
                .collect(Collectors.groupingBy(p -> {
                    if (p instanceof Novel) return "�Ҽ�";
                    else if (p instanceof Magazine) return "����";
                    else return "������";
                }));

        System.out.println("1. Ÿ�Ժ� ��� ����:");
        typeGroups.forEach((type, list) -> {
            double avg = list.stream().mapToInt(Publication::getPrice).average().orElse(0);
            System.out.printf("   - %s: %,d��\n", type, Math.round(avg));
        });

        System.out.println("\n2. ���ǹ� ���� ����:");
        int total = publications.size();
        typeGroups.forEach((type, list) -> {
            double ratio = (list.size() * 100.0) / total;
            System.out.printf("   - %s: %.2f%%\n", type, ratio);
        });

        System.out.println("\n3. 2007�⿡ ���ǵ� ���ǹ� ����: ");
        long count2007 = publications.stream()
                .filter(p -> p.getPublishDate().getYear() == 2007)
                .count();
        double ratio2007 = (count2007 * 100.0) / total;
        System.out.printf("   - %.2f%%\n", ratio2007);
        System.out.println("=============================");
    }
}
