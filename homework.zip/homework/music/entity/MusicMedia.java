package music.entity;

public abstract class MusicMedia {
    protected String title;
    protected String artist;

    public MusicMedia(String title, String artist) {
        this.title = title;
        this.artist = artist;
    }

    public abstract void play();

    public void displayInfo() {
        System.out.printf("����: %s, ��Ƽ��Ʈ: %s\n", title, artist);
    }
}

// Playable.java
package workshop.music.entity;

public interface Playable {
    void setVolume(int level);
    void stop();
}

// DigitalMedia.java
package workshop.music.entity;

public class DigitalMedia extends MusicMedia {
    protected String format;

    public DigitalMedia(String title, String artist, String format) {
        super(title, artist);
        this.format = format;
    }

    @Override
    public void play() {
        System.out.printf("%s ������ '%s'��(��) �����з� ����˴ϴ�.\n", format, title);
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("����: " + format);
    }
}

// MP3.java
package workshop.music.entity;

public class MP3 extends DigitalMedia implements Playable {
    private int fileSize;
    private int volume;

    public MP3(String title, String artist, int fileSize) {
        this(title, artist, fileSize, 5);
    }

    public MP3(String title, String artist, int fileSize, int volume) {
        super(title, artist, "MP3");
        this.fileSize = fileSize;
        this.volume = volume;
    }

    @Override
    public void play() {
        super.play();
        System.out.println("���� ����: " + volume);
    }

    @Override
    public void setVolume(int level) {
        this.volume = level;
        System.out.println("������ " + volume + "�� �����Ǿ����ϴ�.");
    }

    @Override
    public void stop() {
        System.out.println("MP3 ����� �����Ǿ����ϴ�.");
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.printf("���� ũ��: %dMB\n", fileSize);
    }
}

// Vinyl.java
package workshop.music.entity;

public class Vinyl extends MusicMedia {
    private int rpm;

    public Vinyl(String title, String artist, int rpm) {
        super(title, artist);
        this.rpm = rpm;
    }

    @Override
    public void play() {
        System.out.printf("���̴� ���ڵ� '%s'��(��) %drpm���� ����˴ϴ�.\n", title, rpm);
    }

    public void clean() {
        System.out.println("���̴� ���ڵ带 û���մϴ�.");
    }
}

// MusicPlayerTest.java
package workshop.music.control;

import workshop.music.entity.*;

public class MusicPlayerTest {
    public static void main(String[] args) {
        System.out.println("===== ���� ��� �ý��� �׽�Ʈ =====\n");

        System.out.println("--- MP3 �׽�Ʈ ---");
        MP3 mp3 = new MP3("Dynamite", "BTS", 5);
        mp3.displayInfo();
        mp3.play();
        mp3.setVolume(8);
        mp3.play();
        mp3.stop();

        System.out.println("\n--- Vinyl �׽�Ʈ ---");
        Vinyl vinyl = new Vinyl("Yesterday", "The Beatles", 33);
        vinyl.displayInfo();
        vinyl.play();
        vinyl.clean();

        System.out.println("\n--- ������ �׽�Ʈ ---");
        MusicMedia media = new MP3("Butter", "BTS", 4);
        media.displayInfo();
        media.play();

        System.out.println("\n--- ĳ���� �׽�Ʈ ---");
        if (media instanceof MP3) {
            MP3 casted = (MP3) media;
            casted.setVolume(3);
            casted.play();
            casted.setVolume(7);
            casted.stop();
        }
    }
}

