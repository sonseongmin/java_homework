// Account.java
package bank.entity;

public abstract class Account {
    private String accountNumber;
    private String ownerName;
    protected double balance;

    public Account(String accountNumber, String ownerName, double balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName() { return ownerName; }
    public double getBalance() { return balance; }

    public void deposit(double amount) {
        balance += amount;
        System.out.printf("%.1f���� �ԱݵǾ����ϴ�. ���� �ܾ�: %.1f��\n", amount, balance);
    }

    public void withdraw(double amount) throws Exception {
        if (balance < amount) {
            throw new workshop.bank.exception.InsufficientBalanceException("�ܾ��� �����մϴ�.");
        }
        balance -= amount;
        System.out.printf("%.1f���� ��ݵǾ����ϴ�. ���� �ܾ�: %.1f��\n", amount, balance);
    }

    public abstract void displayInfo();
}

// SavingsAccount.java
package workshop.bank.entity;

public class SavingsAccount extends Account {
    private double interestRate;

    public SavingsAccount(String accountNumber, String ownerName, double balance, double interestRate) {
        super(accountNumber, ownerName, balance);
        this.interestRate = interestRate;
    }

    public void applyInterest() {
        double interest = balance * (interestRate / 100);
        deposit(interest);
        System.out.printf("���� %.1f���� ����Ǿ����ϴ�. ���� �ܾ�: %.1f��\n", interest, balance);
    }

    @Override
    public void displayInfo() {
        System.out.printf("���¹�ȣ: %s, ������: %s, �ܾ�: %.1f��, ������: %.1f%%\n",
                getAccountNumber(), getOwnerName(), balance, interestRate);
    }
}

// CheckingAccount.java
package workshop.bank.entity;

import workshop.bank.exception.WithdrawalLimitExceededException;

public class CheckingAccount extends Account {
    private double withdrawalLimit;

    public CheckingAccount(String accountNumber, String ownerName, double balance, double withdrawalLimit) {
        super(accountNumber, ownerName, balance);
        this.withdrawalLimit = withdrawalLimit;
    }

    @Override
    public void withdraw(double amount) throws Exception {
        if (amount > withdrawalLimit) {
            throw new WithdrawalLimitExceededException("��� �ѵ��� �ʰ��߽��ϴ�. �ѵ�: " + withdrawalLimit + "��");
        }
        super.withdraw(amount);
    }

    @Override
    public void displayInfo() {
        System.out.printf("���¹�ȣ: %s, ������: %s, �ܾ�: %.1f��, ��� �ѵ�: %.1f��\n",
                getAccountNumber(), getOwnerName(), balance, withdrawalLimit);
    }
}

// Bank.java
package workshop.bank.entity;

import workshop.bank.exception.*;
import java.util.*;

public class Bank {
    private List<Account> accounts = new ArrayList<>();
    private int accountSequence = 1000;

    public Account createSavingsAccount(String owner, double balance, double rate) {
        String accNo = "AC" + accountSequence++;
        Account acc = new SavingsAccount(accNo, owner, balance, rate);
        accounts.add(acc);
        System.out.println("Saving(����) ���°� �����Ǿ����ϴ�: " + accNo);
        return acc;
    }

    public Account createCheckingAccount(String owner, double balance, double limit) {
        String accNo = "AC" + accountSequence++;
        Account acc = new CheckingAccount(accNo, owner, balance, limit);
        accounts.add(acc);
        System.out.println("üŷ ���°� �����Ǿ����ϴ�: " + accNo);
        return acc;
    }

    public Account findAccount(String accNo) throws AccountNotFoundException {
        return accounts.stream()
                .filter(acc -> acc.getAccountNumber().equals(accNo))
                .findFirst()
                .orElseThrow(() -> new AccountNotFoundException("���¹�ȣ " + accNo + "�� �ش��ϴ� ���¸� ã�� �� �����ϴ�."));
    }

    public void transfer(String fromAccNo, String toAccNo, double amount) throws Exception {
        Account from = findAccount(fromAccNo);
        Account to = findAccount(toAccNo);
        from.withdraw(amount);
        to.deposit(amount);
        System.out.printf("%.1f���� %s���� %s�� �۱ݵǾ����ϴ�.\n", amount, fromAccNo, toAccNo);
    }

    public void printAllAccounts() {
        System.out.println("=== ��� ���� ��� ===");
        accounts.forEach(Account::displayInfo);
        System.out.println("===================");
    }
}

// AccountNotFoundException.java
package workshop.bank.exception;

public class AccountNotFoundException extends Exception {
    public AccountNotFoundException(String message) {
        super(message);
    }
}

// InsufficientBalanceException.java
package workshop.bank.exception;

public class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) {
        super(message);
    }
}

// WithdrawalLimitExceededException.java
package workshop.bank.exception;

public class WithdrawalLimitExceededException extends InsufficientBalanceException {
    public WithdrawalLimitExceededException(String message) {
        super(message);
    }
}

// BankDemo.java
package workshop.bank.control;

import workshop.bank.entity.*;
import workshop.bank.exception.*;

public class BankDemo {
    public static void main(String[] args) {
        Bank bank = new Bank();

        // ���� ����
        Account a1 = bank.createSavingsAccount("ȫ�浿", 10000, 3.0);
        Account a2 = bank.createCheckingAccount("��ö��", 20000, 5000);
        Account a3 = bank.createSavingsAccount("�̿���", 30000, 2.0);

        bank.printAllAccounts();

        System.out.println("\n=== �Ա�/��� �׽�Ʈ ===");
        a1.deposit(5000);
        try {
            a2.withdraw(3000);
        } catch (Exception e) {
            System.out.println("���� �߻�: " + e.getMessage());
        }

        System.out.println("\n=== ���� ���� �׽�Ʈ ===");
        if (a1 instanceof SavingsAccount sa) {
            sa.applyInterest();
        }

        System.out.println("\n=== ���� ��ü �׽�Ʈ ===");
        try {
            bank.transfer("AC1002", "AC1001", 5000);
        } catch (Exception e) {
            System.out.println("���� �߻�: " + e.getMessage());
        }

        bank.printAllAccounts();

        System.out.println("\n=== ���� ó�� �׽�Ʈ ===");
        try {
            a2.withdraw(6000);
        } catch (Exception e) {
            System.out.println("���� �߻�: " + e.getMessage());
        }

        try {
            bank.findAccount("AC9999");
        } catch (Exception e) {
            System.out.println("���� �߻�: " + e.getMessage());
        }
    }
}
